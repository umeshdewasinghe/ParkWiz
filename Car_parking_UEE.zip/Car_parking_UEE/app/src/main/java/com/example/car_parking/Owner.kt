package com.example.car_parking

data class owner(val ownername  :String? =null,val  Passwored : String?=null,val email : String?=null,val type : String?=null)
