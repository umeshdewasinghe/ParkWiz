package com.example.car_parking

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.car_parking.R

class Testowner : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_testowner)
    }
}