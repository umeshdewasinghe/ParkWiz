package com.example.car_parking

data class userdata(val Username  :String? =null,val  Passwored : String?=null,val email : String?=null,val typs : String?=null)
