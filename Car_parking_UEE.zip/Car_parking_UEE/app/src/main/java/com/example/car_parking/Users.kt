package com.example.car_parking

data class Users(
    var customerId:String? = null,
    var customerEmail:String?=null,
    val customerName: String?=null,
    val customerSubject:String?=null,
    var customerPhone:String?=null,
    var customerMessage:String?=null,


)
